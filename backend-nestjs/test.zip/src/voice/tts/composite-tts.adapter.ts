﻿import { Injectable } from '@nestjs/common';
import { DhvaaniAdapter } from './dhvaani.adapter';
import { PiperAdapter } from './piper.adapter';
import type { TextToSpeechPort, TtsAudioChunk, TtsRequest, TtsVoiceOption } from './tts.port';
import type { VoiceLanguage } from '../voice.types';

@Injectable()
export class CompositeTtsAdapter implements TextToSpeechPort {
  readonly engineId = 'composite';

  constructor(
    private readonly dhvaani: DhvaaniAdapter,
    private readonly piper: PiperAdapter,
  ) {}

  supports(language: VoiceLanguage): boolean {
    return this.dhvaani.supports(language) || this.piper.supports(language);
  }

  supportsVoice(language: VoiceLanguage, voice: string): boolean {
    return (
      this.dhvaani.supportsVoice(language, voice) ||
      this.piper.supportsVoice(language, voice)
    );
  }

  voices(language: VoiceLanguage): readonly TtsVoiceOption[] {
    const combined = [
      ...this.dhvaani.voices(language),
      ...this.piper.voices(language),
    ];

    return combined.filter(
      (voice, index, all) =>
        all.findIndex((item) => item.id === voice.id) === index,
    );
  }

  async *synthesize(request: TtsRequest): AsyncIterable<TtsAudioChunk> {
    if (this.dhvaani.supportsVoice(request.language, request.voice)) {
      yield* this.dhvaani.synthesize(request);
      return;
    }

    if (this.piper.supportsVoice(request.language, request.voice)) {
      yield* this.piper.synthesize(request);
      return;
    }

    throw new Error('Requested TTS voice is not supported');
  }

  async healthCheck(): Promise<boolean> {
    const results = await Promise.allSettled([
      this.dhvaani.healthCheck(),
      this.piper.healthCheck(),
    ]);

    return results.some(
      (result) => result.status === 'fulfilled' && result.value,
    );
  }
}
